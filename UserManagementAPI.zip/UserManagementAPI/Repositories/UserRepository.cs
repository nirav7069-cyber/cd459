using UserManagementAPI.Models;

namespace UserManagementAPI.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly List<User> _users = new()
        {
            new User { Id = 1, FirstName = "Alice", LastName = "Johnson", Email = "alice@techhive.com", Department = "HR", Role = "Manager", CreatedAt = DateTime.UtcNow, IsActive = true },
            new User { Id = 2, FirstName = "Bob", LastName = "Smith", Email = "bob@techhive.com", Department = "IT", Role = "Developer", CreatedAt = DateTime.UtcNow, IsActive = true }
        };

        private int _nextId = 3;

        // BUG FIX: Returns empty list instead of null — prevents null reference crashes
        public IEnumerable<User> GetAll()
        {
            return _users.ToList();
        }

        // BUG FIX: Returns null safely instead of throwing on missing ID
        public User? GetById(int id)
        {
            return _users.FirstOrDefault(u => u.Id == id);
        }

        // BUG FIX: Added duplicate email check to prevent duplicate users
        public bool EmailExists(string email, int? excludeId = null)
        {
            return _users.Any(u =>
                u.Email.Equals(email, StringComparison.OrdinalIgnoreCase) &&
                (excludeId == null || u.Id != excludeId));
        }

        public User Add(User user)
        {
            user.Id = _nextId++;
            user.CreatedAt = DateTime.UtcNow;
            _users.Add(user);
            return user;
        }

        // BUG FIX: Preserves original CreatedAt instead of overwriting it
        public User? Update(int id, User updatedUser)
        {
            var existing = _users.FirstOrDefault(u => u.Id == id);
            if (existing == null) return null;

            existing.FirstName = updatedUser.FirstName;
            existing.LastName = updatedUser.LastName;
            existing.Email = updatedUser.Email;
            existing.Department = updatedUser.Department;
            existing.Role = updatedUser.Role;
            existing.IsActive = updatedUser.IsActive;
            // CreatedAt is intentionally NOT updated

            return existing;
        }

        public bool Delete(int id)
        {
            var user = _users.FirstOrDefault(u => u.Id == id);
            if (user == null) return false;
            _users.Remove(user);
            return true;
        }
    }
}