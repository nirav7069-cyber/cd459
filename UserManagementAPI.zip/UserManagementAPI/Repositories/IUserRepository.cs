using UserManagementAPI.Models;

namespace UserManagementAPI.Repositories
{
    public interface IUserRepository
    {
        IEnumerable<User> GetAll();
        User? GetById(int id);
        bool EmailExists(string email, int? excludeId = null);
        User Add(User user);
        User? Update(int id, User user);
        bool Delete(int id);
    }
}