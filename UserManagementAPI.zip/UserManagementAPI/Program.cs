using UserManagementAPI.Middleware;
using UserManagementAPI.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddSingleton<IUserRepository, UserRepository>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// =============================================
// MIDDLEWARE PIPELINE — ORDER MATTERS
// =============================================

// 1. Error Handling — must be FIRST to catch all downstream exceptions
app.UseErrorHandling();

// 2. Authentication — must come BEFORE logging and controllers
app.UseTokenAuthentication();

// 3. Logging — logs after auth so only valid requests are fully logged
app.UseRequestLogging();

// 4. Swagger — only in development
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// 5. Standard ASP.NET Core pipeline
app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();