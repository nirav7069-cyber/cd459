namespace UserManagementAPI.Middleware
{
    public class TokenAuthenticationMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<TokenAuthenticationMiddleware> _logger;
        private readonly IConfiguration _configuration;

        public TokenAuthenticationMiddleware(
            RequestDelegate next,
            ILogger<TokenAuthenticationMiddleware> logger,
            IConfiguration configuration)
        {
            _next = next;
            _logger = logger;
            _configuration = configuration;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Skip auth for Swagger UI paths
            var path = context.Request.Path.Value ?? "";
            if (path.StartsWith("/swagger", StringComparison.OrdinalIgnoreCase))
            {
                await _next(context);
                return;
            }

            // Check for Authorization header
            if (!context.Request.Headers.TryGetValue("Authorization", out var authHeader))
            {
                _logger.LogWarning("[AUTH] Missing Authorization header. Path: {Path}", context.Request.Path);
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                await context.Response.WriteAsJsonAsync(new
                {
                    error = "Unauthorized. Authorization header is missing.",
                    statusCode = 401,
                    timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
                });
                return;
            }

            // Validate token format: "Bearer <token>"
            var headerValue = authHeader.ToString();
            if (!headerValue.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning("[AUTH] Invalid token format. Path: {Path}", context.Request.Path);
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                await context.Response.WriteAsJsonAsync(new
                {
                    error = "Unauthorized. Token format must be: Bearer <token>",
                    statusCode = 401,
                    timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
                });
                return;
            }

            var token = headerValue.Substring("Bearer ".Length).Trim();
            var validToken = _configuration["Auth:Token"] ?? "techhive-secret-token";

            if (token != validToken)
            {
                _logger.LogWarning("[AUTH] Invalid token provided. Path: {Path}", context.Request.Path);
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                await context.Response.WriteAsJsonAsync(new
                {
                    error = "Unauthorized. Invalid token.",
                    statusCode = 401,
                    timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
                });
                return;
            }

            _logger.LogInformation("[AUTH] Token validated successfully. Path: {Path}", context.Request.Path);
            await _next(context);
        }
    }

    // Extension method for clean registration in Program.cs
    public static class TokenAuthenticationMiddlewareExtensions
    {
        public static IApplicationBuilder UseTokenAuthentication(this IApplicationBuilder app)
        {
            return app.UseMiddleware<TokenAuthenticationMiddleware>();
        }
    }
}