namespace UserManagementAPI.Middleware
{
    public class RequestLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<RequestLoggingMiddleware> _logger;

        public RequestLoggingMiddleware(RequestDelegate next, ILogger<RequestLoggingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Log incoming request
            _logger.LogInformation(
                "[REQUEST] {Method} {Path} | Time: {Time}",
                context.Request.Method,
                context.Request.Path,
                DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
            );

            // Call next middleware
            await _next(context);

            // Log outgoing response
            _logger.LogInformation(
                "[RESPONSE] {Method} {Path} | Status: {StatusCode} | Time: {Time}",
                context.Request.Method,
                context.Request.Path,
                context.Response.StatusCode,
                DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
            );
        }
    }

    // Extension method for clean registration in Program.cs
    public static class RequestLoggingMiddlewareExtensions
    {
        public static IApplicationBuilder UseRequestLogging(this IApplicationBuilder app)
        {
            return app.UseMiddleware<RequestLoggingMiddleware>();
        }
    }
}