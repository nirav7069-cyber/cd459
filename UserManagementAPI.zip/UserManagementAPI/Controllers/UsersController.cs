using Microsoft.AspNetCore.Mvc;
using UserManagementAPI.Models;
using UserManagementAPI.Repositories;

namespace UserManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IUserRepository _repository;
        private readonly ILogger<UsersController> _logger;

        public UsersController(IUserRepository repository, ILogger<UsersController> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        // GET: api/users
        // BUG FIX: Wrapped in try-catch to prevent unhandled crashes
        [HttpGet]
        public ActionResult<IEnumerable<User>> GetAllUsers()
        {
            try
            {
                var users = _repository.GetAll();
                return Ok(users);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving all users.");
                return StatusCode(500, new { message = "An internal error occurred while retrieving users." });
            }
        }

        // GET: api/users/{id}
        // BUG FIX: Returns 404 with clear message instead of crashing on missing user
        [HttpGet("{id}")]
        public ActionResult<User> GetUserById(int id)
        {
            try
            {
                if (id <= 0)
                    return BadRequest(new { message = "ID must be a positive integer." });

                var user = _repository.GetById(id);
                if (user == null)
                    return NotFound(new { message = $"User with ID {id} was not found." });

                return Ok(user);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving user with ID {Id}.", id);
                return StatusCode(500, new { message = "An internal error occurred while retrieving the user." });
            }
        }

        // POST: api/users
        // BUG FIX: Validates model + checks for duplicate emails before inserting
        [HttpPost]
        public ActionResult<User> CreateUser([FromBody] User user)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                if (_repository.EmailExists(user.Email))
                    return Conflict(new { message = $"A user with email '{user.Email}' already exists." });

                var created = _repository.Add(user);
                return CreatedAtAction(nameof(GetUserById), new { id = created.Id }, created);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating user.");
                return StatusCode(500, new { message = "An internal error occurred while creating the user." });
            }
        }

        // PUT: api/users/{id}
        // BUG FIX: Validates model, checks user exists, and prevents email conflict with other users
        [HttpPut("{id}")]
        public ActionResult<User> UpdateUser(int id, [FromBody] User user)
        {
            try
            {
                if (id <= 0)
                    return BadRequest(new { message = "ID must be a positive integer." });

                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                if (_repository.GetById(id) == null)
                    return NotFound(new { message = $"User with ID {id} was not found." });

                if (_repository.EmailExists(user.Email, excludeId: id))
                    return Conflict(new { message = $"Another user with email '{user.Email}' already exists." });

                var updated = _repository.Update(id, user);
                return Ok(updated);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating user with ID {Id}.", id);
                return StatusCode(500, new { message = "An internal error occurred while updating the user." });
            }
        }

        // DELETE: api/users/{id}
        // BUG FIX: Returns 404 clearly instead of silent failure
        [HttpDelete("{id}")]
        public ActionResult DeleteUser(int id)
        {
            try
            {
                if (id <= 0)
                    return BadRequest(new { message = "ID must be a positive integer." });

                var deleted = _repository.Delete(id);
                if (!deleted)
                    return NotFound(new { message = $"User with ID {id} was not found." });

                return Ok(new { message = $"User with ID {id} was successfully deleted." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting user with ID {Id}.", id);
                return StatusCode(500, new { message = "An internal error occurred while deleting the user." });
            }
        }
    }
}